function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6h5KqPmnS7U":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

